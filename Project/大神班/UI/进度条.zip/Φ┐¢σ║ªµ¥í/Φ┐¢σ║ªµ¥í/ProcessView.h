//
//  ProcessView.h
//  进度条
//
//  Created by yang on 2019/5/5.
//  Copyright © 2019 XingYeTechnology. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ProcessView : UIView


@property (nonatomic,assign)CGFloat process;
@end

NS_ASSUME_NONNULL_END
